Vue.component('product-item', {
  props: ['item'],
  template: `
  <div id="item">
    <div id="product-image">
      <img :src="item.src">
    </div>
    <div id="product-details">
      <h2>{{item.name}}</h2>
      <p>{{item.des}}</p>
    </div>
    <h1 id="theprice">{{item.price}}</h1>
    <button @click="$emit('add',item.id)" id="cart-button">Add to cart</button>
    <button @click="$emit('remove',item.id)" id="cart-remove">Remove from cart</button>
  </div>`
})


var app = new Vue({
  el: '#app',
  data: {
    company: 'MediHub',
    ph: '+91 9781179665',
    email: 'bajajab@deakin.edu.au',
    github: 'Github Profile',
    linkedin: 'LinkedIn Profile',
    isproduct: true,
    isabout: false,
    iscontact: false,
    isfeedback: false,
    islogin: false,
    isbaby: true,
    iscosmetic: false,
    isvet: false,
    ismedicine: false,
    iscart: false,
    cart: [],
    finalcart: [],
    products: [{ src: "https://m.media-amazon.com/images/I/71TAlBWT61L._SL1500_.jpg", name: "Pampers Baby Wipes", des: "Pampers wipes are safe as they are paraben-free and infused with Vitamin-E. They help restore the natural pH of your baby's skin, keeping it healthy and nourished. Pampers wipes are thick, soft and strong, ensuring a perfect, gentle cleaning for the baby's skin.", price: "$4", type: "baby", id: "A1", qty: 1 },
    { src: "https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600213828/cropped/ovfee30zdp1uy0u23jj7.jpg", name: "Mamy Poko Pants", des: "These Pant Style Diapers can be worn easily by just pulling up and its soft elastic is gentle on your baby's sensitive skin. Fits comfortably and prevents leakage. Soaks the wetness and keeps your baby dry.", price: "$2", type: "baby", id: "A2", qty: 1 },
    { src: "https://www.johnsonsbaby.com/sites/jbaby_us_3/files/product-images/jns_381371177301_400ml_00000_1000wx1000h.jpeg", name: "Johnson Baby Shampoo", des: "Johnson's Baby Shampoo is our mildest formula shampoo that is specially designed to gently cleanse your baby's fine hair and delicate scalp. It quickly lathers and rinses easily, leaving the hair soft, shiny and manageable and feeling healthy and clean.", price: "$3", type: "baby", id: "A3", qty: 1 },
    { src: "https://m.media-amazon.com/images/I/31CDDcTVReL.jpg", name: "Johnson Baby Powder", des: "Made with purified talc, JOHNSON'S Baby Powder absorbs excess moisture to keep your baby's skin comfortable, dry and feeling healthy all day long. With a clean and classic fragrance, this powder glides over the skin and leaves it feeling soft.", price: "$1", type: "baby", id: "A4", qty: 1 },
    { src: "https://m.media-amazon.com/images/I/51+zjkuAMOL.jpg", name: "Himalaya Baby Products Gift pack", des: "Give complete skin care to your little one with the Himalaya Herbal Babycare gift pack. This baby care pack includes a gentle baby shampoo (100 ml), baby massage oil (100 ml), diaper rash cream (20 g), gentle baby soap (75 g), baby lotion (100 ml), baby powder (100 g) and gentle baby wipes (pack of 12).", price: "$10", type: "baby", id: "A5", qty: 1 },

    { src: "https://m.media-amazon.com/images/I/71xldaquhAL._SL1500_.jpg", name: "Fair and handsome", des: "Fair And Handsome Fairness Cream Is the best cream to hit for men's tough skin. It lightens and clean pores and remove dead skin cells. And also helps reduce acne, pimples and fight skin diseases. It also protects from sun tanning and the UVA, UVB rays caused during the work time.", price: "$2", type: "cosmetic", id: "B1", qty: 1 },
    { src: "https://rukminim1.flixcart.com/image/416/416/jkobte80/deodorant/3/z/z/240-fresh-oriental-fragrance-body-spray-120-ml-fresh-spicy-original-imaejgvdve8jhpct.jpeg?q=70", name: "Fogg Body Spray", des: "FOGG, a brand of scents and deodorants that took the Indian market by surprise, belongs to Vini Cosmetics. ... FOGG deo sprays are high on fragrance and no gas, making these products last longer. Each canister gives about 800 sprays", price: "$3", type: "cosmetic", id: "B2", qty: 1 },
    { src: "https://www.bigbasket.com/media/uploads/p/xxl/40179458_4-clean-clear-morning-energy-aqua-splash-face-wash.jpg", name: "Clean and clear Face Wash", des: "Clean & Clear Foaming Face Wash helps prevent oily skin and pimples. Its rich foam gently cleanses to remove dirt without drying your skin. It is specially designed unique formulation cleanses skin thoroughly preventing common skin problems..", price: "$4", type: "cosmetic", id: "B3", qty: 1 },
    { src: "https://rukminim1.flixcart.com/image/416/416/ksyz8280/antiseptic/3/f/m/disinfectant-multi-use-hygiene-liquid-menthol-cool-500-ml-dettol-original-imag6fyfdmjgg97t.jpeg?q=70", name: "Dettol Disinfectant", des: "Dettol Liquid Antiseptic Disinfectant is a proven effective concentrated antiseptic disinfectant that kills bacteria and provides protection against bacteria which can cause infection and illness. It can be used for gentle antiseptic wound cleansing and disinfection and antiseptic skin cleansing.", price: "$5", type: "cosmetic", id: "B4", qty: 1 },
    { src: "https://media6.ppl-media.com/tr:h-750,w-750,c-at_max/static/img/product/212173/sunsilk-perfect-straight-shampoo-340-ml-1_1_display_1609163154_a7b91d2a.jpg", name: "Sunsilk Shampoo", des: "Sunsilk significantly improved product formula and launched new variants in 1966: the first major shampoo to contain olive oil, which acted as conditioner to make hair soft and manageable; shampoo for dull hair, which restored hair's natural shine; lemon shampoo for greasy hair with deep cleansing ingredients.", price: "$7", type: "cosmetic", id: "B5", qty: 1 },

    { src: "https://in.virbac.com/files/live/sites/virbac-in/files/predefined-files/products/600px/Enriched%20Ostovet%205%20ltr%20600x600.png", name: "Ostovet calcium", des: "Liquid is a cattle feed supplement high-bioavailable Calcium, Vitamin D3, Vitamin B12, and Phosphorous for lactating cattle. ... OSTOVET® Liquid is fortified with Calcium, Phosphorus, Vitamins D3, Vitamin B12, and Phosphorous for ensuring optimum milk yield and good health of cattle.", price: "$110", type: "vet", id: "C1", qty: 1 },
    { src: "https://th.bing.com/th/id/OIP.VZYtmxyf2NAmEXDm6sh8UgHaG6?w=212&h=198&c=7&r=0&o=5&dpr=1.12&pid=1.7", name: "Pedigree Dog Food", des: "Pedigree is a grain-inclusive dry dog food using a moderate amount of named and unnamed meat by-product meals as its main source of animal protein, thus earning the brand 5 star.", price: "$30", type: "vet", id: "C2", qty: 1 },
    { src: "https://in.virbac.com/files/live/sites/virbac-in/files/predefined-files/products/600px/Agrimin%20Forte%2020kg%20-%20Cattle.png", name: "Agrimin Forte", des: "AGRIMIN FORTE is a high-quality mineral feed additive for dairy cattle that improves cattle fertility. It improves the reproductive health of cattle and helps to maintain pregnancy. Features Facts.", price: "$100", type: "vet", id: "C3", qty: 1 },
    { src: "https://th.bing.com/th/id/OIP.pvW6gnPpdqBbDIdxOUXcDgHaHM?w=181&h=180&c=7&r=0&o=5&dpr=1.12&pid=1.7", name: "Vimeral", des: "VIMERAL is a proven anti-stress feed supplement for poultry. It provides higher bioavailability for optimum absorption, with a high concentration of Vitamin E and Vitamin B12, Vitamin D3 and Vitamin A in palmitate form. Features Facts. Acts as an anti-stress feed supplement for poultry. Acts as immunostimulant.", price: "$70", type: "vet", id: "C4", qty: 1 },
    { src: "https://th.bing.com/th/id/OIP.8A_GefkGNw_ULq8g9Nh_YAAAAA?pid=ImgDet&rs=1", name: "Avil Injection 10ml", des: "Itching of unknown genesis and of various localization, eczema, dermatitis, urticaria, skin oedema, insect bites, photodermatitis, rhinitis, tail eczema in horses, stomatitis, toxic hoof corns and inflammation of the hooves of cattle, paresis during pregnancy, puerperal toxemia and secondary retention, pulmonary oedema .", price: "$50", type: "vet", id: "C5", qty: 1 },

    { src: "https://www.medwik.in/wp-content/uploads/2020/08/fenak-plus-tablet.jpg", name: "Fenak Plus", des: "Fenak Plus Tablet is a pain relieving medicine. It is used to reduce pain and inflammation in conditions like rheumatoid arthritis, ankylosing spondylitis, and osteoarthritis. It may also be used to relieve muscle pain, back pain, toothache, or pain in the ear and throat. Fenak Plus Tablet should be taken with food.", price: "$2", type: "medicine", id: "D1", qty: 1 },
    { src: "https://www.netmeds.com/images/product-v1/600x600/45285/calpol_500mg_tablet_15_s_0.jpg", name: "Calpol 500 mg", des: "Calpol 500mg Tablet 15's contains 'Paracetamol' which is a mild analgesic and fever reducer. Calpol 500mg Tablet 15's can also be used to treat mild to moderate pain in conditions of headache, toothache, backache, period pain, and muscle pain.", price: "$3", type: "medicine", id: "D2", qty: 1 },
    { src: "https://newassets.apollo247.com/pub/media/catalog/product/a/c/aci0006.jpg", name: "Aciloc 300", des: "Aciloc 300 Tablet is a medicine that reduces the amount of acid your stomach makes. It is used to treat and prevent heartburn, indigestion, and other symptoms caused by too much acid in the stomach. It is also used to treat and prevent stomach ulcers, reflux disease, and some rarer conditions.", price: "$2", type: "medicine", id: "D3", qty: 1 },
    { src: "https://urbanhelps.com/wp-content/uploads/2020/05/w7zchjm1feui7vvfyrxr.jpg", name: "Revital H", des: "Revital H Capsule is a combination of vitamins and minerals that helps to support daily energy needs. Ginseng helps to improve concentration and also increases oxygen consumption in the body. It helps to maintain energy and stamina throughout the day.", price: "$9", type: "medicine", id: "D4", qty: 1 },
    { src: "https://newassets.apollo247.com/pub/media/catalog/product/b/e/ben0053.jpg", name: "Benadryl Cough Syrup", des: "Benadryl Syrup is a combination of three medicines: Diphenhydramine, Ammonium chloride and Sodium citrate, which relieves cough. Diphenhydramine is an antiallergic which relieves allergy symptoms like runny nose, watery eyes and sneezing.", price: "$20", type: "medicine", id: "D5", qty: 1 }]
  },
  methods: {
    toogleproduct: function () {
      this.isproduct = true;
      this.isabout = false;
      this.iscontact = false;
      this.isfeedback = false;
      this.islogin = false;
    },
    toogleabout: function () {
      this.isproduct = false;
      this.isabout = true;
      this.iscontact = false;
      this.isfeedback = false;
      this.islogin = false;
    },
    tooglecontact: function () {
      this.isproduct = false;
      this.isabout = false;
      this.iscontact = true;
      this.isfeedback = false;
      this.islogin = false;
    },
    tooglefeedback: function () {
      this.isproduct = false;
      this.isabout = false;
      this.iscontact = false;
      this.isfeedback = true;
      this.islogin = false;
    },
    tooglelogin: function () {
      this.isproduct = false;
      this.isabout = false;
      this.iscontact = false;
      this.isfeedback = false;
      this.islogin = true;
    },
    toogleproduct: function () {
      this.isproduct = true;
      this.isabout = false;
      this.iscontact = false;
      this.isfeedback = false;
      this.islogin = false;
    },
    tooglebaby: function () {
      this.isbaby = true;
      this.isvet = false;
      this.iscosmetic = false;
      this.ismedicine = false;
    },
    tooglevet: function () {
      this.isbaby = false;
      this.isvet = true;
      this.iscosmetic = false;
      this.ismedicine = false;
    },
    tooglecosmetic: function () {
      this.isbaby = false;
      this.isvet = false;
      this.iscosmetic = true;
      this.ismedicine = false;
    },
    tooglemedicine: function () {
      this.isbaby = false;
      this.isvet = false;
      this.iscosmetic = false;
      this.ismedicine = true;
    },
    contains: function (obj, list) {
      var i;
      for (i = 0; i < list.length; i++) {
        if (list[i] === obj) {
          return true;
        }
      }
      return false;
    },

    mounted() {
      const loginText = document.querySelector(".title-text .login");
      const loginForm = document.querySelector("form.login");
      const loginBtn = document.querySelector("label.login");
      const signupBtn = document.querySelector("label.signup");
      const signupLink = document.querySelector("form .signup-link a");
      signupBtn.onclick = () => {
        loginForm.style.marginLeft = "-50%";
        loginText.style.marginLeft = "-50%";
      };
      loginBtn.onclick = () => {
        loginForm.style.marginLeft = "0%";
        loginText.style.marginLeft = "0%";
      };
      signupLink.onclick = () => {
        signupBtn.click();
        return false;
      };
      // login1.onclick = () => {
      //    @click="toogleproduct";
      // }
    },

    add: function (id) {
      for (let i = 0; i < this.products.length; i++) {
        var qty = 0;

        if (this.products[i].id == id) {
          if (this.contains(this.products[i], this.cart)) {
            for (let j = 0; j < this.cart.length; j++) {
              if (this.cart[j].id == id) {
                this.cart[j].qty += 1;
              }
            }

            console.log("alreay there");
          }
          else {
            this.cart.push(this.products[i]);
          }
        }
      }
    },
    remove: function (id) {
      for (let i = 0; i < this.products.length; i++) {
        var qty = 0;

        if (this.products[i].id == id) {
          if (this.contains(this.products[i], this.cart)) {
            for (let j = 0; j < this.cart.length; j++) {
              if ((this.cart[j].id == id) && (this.cart[j].qty >= 1)) {
                this.cart[j].qty -= 1;
                if (this.cart[j].qty == 0) {
                  this.cart.pop(this.products[j]);
                }
              }
            }
          }
          else {
            // this.cart.push(this.products[i]);
          }
        }
      }
    },
    myfunc: function() {
      alert("Thanks for placing your order");
    }
  }
})
